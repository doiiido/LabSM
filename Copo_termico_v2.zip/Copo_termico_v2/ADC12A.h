/*
 * ADC12A.h
 *
 *  Created on: 1 de dez de 2017
 *      Author: lincoln
 */

#ifndef ADC12A_H_
#define ADC12A_H_

void setADC();

void setDMA(unsigned short *saida_6_1, unsigned short *saida_6_2, unsigned short *saida_t_amb);

#endif /* ADC12A_H_ */
