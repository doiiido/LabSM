/*
 * I2C.h
 *
 *  Created on: 16 de nov de 2017
 *      Author: lincoln
 */

#ifndef I2C_H_
#define I2C_H_

void I2C_config(void);

void write_I2C(char byte);

void delay_100us (int mult);

#endif
